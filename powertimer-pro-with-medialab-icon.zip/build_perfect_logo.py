import subprocess
import os

DEMI_FONT = "/usr/share/fonts/opentype/urw-base35/URWGothic-Demi.otf"
BOOK_FONT = "/usr/share/fonts/opentype/urw-base35/URWGothic-Book.otf"

# 1. Line 1: medıaLab with dotless i
subprocess.check_call([
    "convert",
    "-background", "none",
    "-fill", "#000000",
    "-font", DEMI_FONT,
    "-pointsize", "76",
    "label:medıaLab",
    "/tmp/l1_raw.png"
])

# Find the exact column of the 'ı' stem (between d and a)
# d ends around x=158, a starts around x=182, stem of 'ı' is at x=165..175 (center = 170), top=14
# Red play triangle ▶
# Points: top-left (164, 1), apex-right (179, 7), bottom-left (164, 13)
subprocess.check_call([
    "convert",
    "/tmp/l1_raw.png",
    "-fill", "#d63f24",
    "-draw", "polygon 164,1 180,7.5 164,14",
    "-trim", "+repage",
    "/tmp/l1_ready.png"
])

# 2. Line 2: publishing
# We render with dotless 'ı's: publıshıng
subprocess.check_call([
    "convert",
    "-background", "none",
    "-fill", "#000000",
    "-font", BOOK_FONT,
    "-pointsize", "56",
    "label:publıshıng",
    "/tmp/l2_raw.png"
])

# Aperture target on 'p':
# p bowl center is at x=20.5, y=25.5
# First 'ı' stem is at x=126, top=11
# Second 'ı' stem is at x=193, top=11
# Diamond dots: rotated square (rhombus) centered at y=5.5
d1 = "polygon 126,1.5 129.5,5.5 126,9.5 122.5,5.5"
d2 = "polygon 193,1.5 196.5,5.5 193,9.5 189.5,5.5"

subprocess.check_call([
    "convert",
    "/tmp/l2_raw.png",
    # Aperture target on 'p'
    "-fill", "none",
    "-stroke", "#f4f2ee",
    "-strokewidth", "3.0",
    "-draw", "circle 20.5,25.5 20.5,35",
    "-stroke", "#000000",
    "-strokewidth", "1.8",
    "-draw", "circle 20.5,25.5 20.5,32",
    "-stroke", "none",
    "-fill", "#f4f2ee",
    "-draw", "circle 20.5,25.5 20.5,29",
    # Crisp Diamonds on both 'i's
    "-fill", "#000000",
    "-draw", d1,
    "-draw", d2,
    "-trim", "+repage",
    "/tmp/l2_ready.png"
])

# 3. Stack Line 1 and Line 2 cleanly
os.makedirs("public", exist_ok=True)
subprocess.check_call([
    "convert",
    "-background", "none",
    "/tmp/l1_ready.png",
    "/tmp/l2_ready.png",
    "-gravity", "West",
    "-append",
    "-bordercolor", "none",
    "-border", "6x4",
    "public/mediaLab_publishing_transparent.png"
])

# Also keep logo.png in sync
subprocess.check_call([
    "cp", "public/mediaLab_publishing_transparent.png", "public/logo.png"
])

print("PERFECT LOGO CREATED AND SAVED TO public/mediaLab_publishing_transparent.png")
subprocess.check_call(["identify", "public/mediaLab_publishing_transparent.png"])
