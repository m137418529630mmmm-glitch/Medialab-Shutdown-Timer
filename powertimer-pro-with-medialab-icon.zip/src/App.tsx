import React, { useState, useEffect, useRef } from 'react';
import { 
  RotateCcw, 
  ArrowDown,
  Clock
} from 'lucide-react';
import { sounds } from './utils/audio';
import { ShutdownConfig } from './utils/scripts';
import { LockScreen } from './components/LockScreen';
import { ExportExeModal } from './components/ExportExeModal';
import { MediaLabLogo } from './components/MediaLabLogo';

type ActionType = 'shutdown' | 'restart' | 'lock' | 'sleep';
type TimeUnit = 'minutes' | 'hours';

export default function App() {
  // Localization: English (default) or Arabic
  const [isArabic, setIsArabic] = useState<boolean>(false);
  
  // Time Unit: Minutes or Hours
  const [timeUnit, setTimeUnit] = useState<TimeUnit>('minutes');
  const [inputValue, setInputValue] = useState<string>('30');
  
  // Timer Configuration
  const [actionType, setActionType] = useState<ActionType>('shutdown');
  const [forceKill, setForceKill] = useState<boolean>(true);
  const [warningSound, setWarningSound] = useState<boolean>(true);
  const [pinProtected, setPinProtected] = useState<boolean>(false);
  const [pinCode, setPinCode] = useState<string>('1234');
  
  // Running State
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [totalSeconds, setTotalSeconds] = useState<number>(30 * 60);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(30 * 60);
  
  // Modals
  const [isLockScreenActive, setIsLockScreenActive] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Calculate total seconds based on current unit
  const calculateSeconds = (valStr: string, unit: TimeUnit): number => {
    const val = parseFloat(valStr);
    if (isNaN(val) || val <= 0) return 0;
    return unit === 'hours' ? Math.round(val * 3600) : Math.round(val * 60);
  };

  const updateDuration = (valStr: string) => {
    setInputValue(valStr);
    const secs = calculateSeconds(valStr, timeUnit);
    if (secs > 0) {
      setTotalSeconds(secs);
      setRemainingSeconds(secs);
    }
  };

  const handleSwitchUnit = (newUnit: TimeUnit) => {
    if (newUnit === timeUnit || isRunning) return;
    sounds.playClick();
    const currentNum = parseFloat(inputValue);
    if (!isNaN(currentNum) && currentNum > 0) {
      if (newUnit === 'hours') {
        // Convert minutes to hours (e.g. 60 -> 1, 30 -> 0.5)
        const hrs = currentNum / 60;
        const formatted = parseFloat(hrs.toFixed(2)).toString();
        setInputValue(formatted);
      } else {
        // Convert hours to minutes (e.g. 1 -> 60, 0.5 -> 30)
        const mins = Math.round(currentNum * 60);
        setInputValue(mins.toString());
      }
    } else {
      setInputValue(newUnit === 'hours' ? '1' : '30');
    }
    setTimeUnit(newUnit);
  };

  const handleApplyPreset = (val: string) => {
    if (isRunning) return;
    sounds.playClick();
    updateDuration(val);
  };

  useEffect(() => {
    if (isRunning && remainingSeconds > 0) {
      timerRef.current = setInterval(() => {
        setRemainingSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setIsRunning(false);
            sounds.playAlarm();
            setIsLockScreenActive(true);
            return 0;
          }
          if (prev === 61 && warningSound) {
            sounds.playAlarm();
          } else if (prev <= 5 && warningSound) {
            sounds.playTick();
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, remainingSeconds, warningSound]);

  const handleToggleTimer = () => {
    if (isRunning) {
      sounds.playCancel();
      setIsRunning(false);
    } else {
      const secs = calculateSeconds(inputValue, timeUnit);
      if (secs <= 0) return;
      setTotalSeconds(secs);
      setRemainingSeconds(secs);
      setIsRunning(true);
      sounds.playStart();
    }
  };

  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progressPercent = totalSeconds > 0 
    ? Math.min(100, Math.max(0, ((totalSeconds - remainingSeconds) / totalSeconds) * 100))
    : 0;

  const currentConfig: ShutdownConfig = {
    action: actionType,
    totalSeconds: isRunning ? remainingSeconds : calculateSeconds(inputValue, timeUnit) || 1800,
    forceKill,
    warningSound,
    pinProtected,
    pinCode,
  };

  return (
    <div 
      className="min-h-screen bg-[#ece9e2] text-[#222] flex flex-col justify-center items-center p-3 sm:p-6 font-sans select-none"
      dir={isArabic ? 'rtl' : 'ltr'}
    >
      
      {/* Main Desktop Card Frame */}
      <div 
        className="w-full max-w-[530px] bg-[#f4f2ee] rounded-2xl shadow-xl border border-neutral-300/80 overflow-hidden p-6 sm:p-8 space-y-6"
      >
          
          {/* Header Row: mediaLab publishing logo on one side, Language Switcher & Category on the other */}
          <div className="flex items-center justify-between gap-4">
            <MediaLabLogo />
            
            <div className="flex flex-col items-end gap-1.5" dir="ltr">
              {/* Language Switcher [ English | عربي ] */}
              <div className="flex items-center bg-[#ece9e2] p-1 rounded-lg border border-neutral-300/70 text-xs font-semibold shadow-2xs">
                <button
                  type="button"
                  onClick={() => {
                    sounds.playClick();
                    setIsArabic(false);
                  }}
                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                    !isArabic 
                      ? 'bg-white text-neutral-900 shadow-xs font-bold' 
                      : 'text-neutral-500 hover:text-neutral-800'
                  }`}
                  title="English (Default)"
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => {
                    sounds.playClick();
                    setIsArabic(true);
                  }}
                  className={`px-2.5 py-1 rounded-md transition-all cursor-pointer ${
                    isArabic 
                      ? 'bg-white text-neutral-900 shadow-xs font-bold' 
                      : 'text-neutral-500 hover:text-neutral-800'
                  }`}
                  title="التبديل إلى اللغة العربية"
                >
                  عربي
                </button>
              </div>

              {/* Category Subtitle */}
              <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase">
                {isArabic ? 'مؤقت الإغلاق والقفل' : 'SHUTDOWN TIMER'}
              </div>
            </div>
          </div>

          {/* Row 1: TIMER DURATION with Unit Switcher (دقائق / سـاعات) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-neutral-500 tracking-wider uppercase">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-neutral-400" />
                <span>
                  {isArabic 
                    ? (timeUnit === 'hours' ? 'مدة المؤقت (بالساعات)' : 'مدة المؤقت (بالدقائق)') 
                    : (timeUnit === 'hours' ? 'TIMER (HOURS)' : 'TIMER (MINUTES)')}
                </span>
              </div>

              {/* Unit Toggle [ دقائق / Minutes | ساعات / Hours ] */}
              <div className="flex items-center bg-[#ece9e2] p-0.5 rounded-lg border border-neutral-300/80 text-[11px] font-bold">
                <button
                  type="button"
                  disabled={isRunning}
                  onClick={() => handleSwitchUnit('minutes')}
                  className={`px-2.5 py-0.5 rounded-md transition-all cursor-pointer disabled:opacity-50 ${
                    timeUnit === 'minutes'
                      ? 'bg-[#e85933] text-white shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  {isArabic ? 'دقائق' : 'Minutes'}
                </button>
                <button
                  type="button"
                  disabled={isRunning}
                  onClick={() => handleSwitchUnit('hours')}
                  className={`px-2.5 py-0.5 rounded-md transition-all cursor-pointer disabled:opacity-50 ${
                    timeUnit === 'hours'
                      ? 'bg-[#e85933] text-white shadow-xs'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  {isArabic ? 'ساعات' : 'Hours'}
                </button>
              </div>
            </div>

            {/* Input with embedded Unit Label and Countdown indicator */}
            <div className="relative">
              <input
                type="number"
                step={timeUnit === 'hours' ? '0.25' : '1'}
                min={timeUnit === 'hours' ? '0.1' : '1'}
                disabled={isRunning}
                value={inputValue}
                onChange={(e) => updateDuration(e.target.value)}
                placeholder={timeUnit === 'hours' ? (isArabic ? '1 ساعة' : '1 hr') : (isArabic ? '30 دقيقة' : '30 min')}
                className={`w-full bg-white border border-neutral-300 rounded-lg py-2.5 text-sm font-semibold text-neutral-900 focus:outline-none focus:border-[#e85933] transition-colors disabled:bg-neutral-100 disabled:text-neutral-400 shadow-xs ${
                  isArabic ? 'pr-4 pl-28 text-right' : 'pl-4 pr-28 text-left'
                }`}
              />
              <div 
                className={`absolute top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none ${
                  isArabic ? 'left-3' : 'right-3'
                }`}
              >
                {isRunning ? (
                  <span className="text-[#e85933] font-mono font-bold text-xs bg-red-50 px-2 py-0.5 rounded border border-red-200">
                    {formatTime(remainingSeconds)}
                  </span>
                ) : (
                  <span className="text-xs font-semibold text-neutral-400 bg-neutral-100 px-2 py-0.5 rounded border border-neutral-200">
                    {timeUnit === 'hours' ? (isArabic ? 'ساعة' : 'hr') : (isArabic ? 'دقيقة' : 'min')}
                  </span>
                )}
              </div>
            </div>

            {/* Quick Presets for fast selection */}
            {!isRunning && (
              <div className="flex items-center gap-1.5 pt-0.5 flex-wrap">
                <span className="text-[10px] font-semibold text-neutral-400">
                  {isArabic ? 'أوقات سريعة:' : 'Quick:'}
                </span>
                {(timeUnit === 'minutes' 
                  ? ['15', '30', '45', '60', '120'] 
                  : ['0.5', '1', '2', '3', '5']
                ).map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => handleApplyPreset(preset)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-colors cursor-pointer ${
                      inputValue === preset
                        ? 'bg-neutral-800 text-white border-neutral-800'
                        : 'bg-white text-neutral-600 border-neutral-300 hover:bg-neutral-50'
                    }`}
                  >
                    {preset} {timeUnit === 'hours' ? (isArabic ? 'س' : 'h') : (isArabic ? 'د' : 'm')}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Row 2: ACTION TYPE */}
          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-neutral-400 tracking-wider uppercase">
              {isArabic ? 'نوع الإجراء' : 'ACTION TYPE'}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'shutdown' as ActionType, ar: 'إغلاق إجباري', en: 'Shutdown' },
                { id: 'restart' as ActionType, ar: 'إعادة تشغيل', en: 'Restart' },
                { id: 'lock' as ActionType, ar: 'قفل الشاشة', en: 'Lock' },
                { id: 'sleep' as ActionType, ar: 'سكون تام', en: 'Sleep' },
              ].map((opt) => {
                const isSelected = actionType === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    disabled={isRunning}
                    onClick={() => {
                      sounds.playClick();
                      setActionType(opt.id);
                    }}
                    className={`py-2 px-1 rounded-lg text-xs font-bold transition-all text-center cursor-pointer disabled:opacity-60 ${
                      isSelected
                        ? 'bg-[#e85933] text-white shadow-sm'
                        : 'bg-white border border-neutral-300 text-neutral-700 hover:bg-neutral-50 shadow-xs'
                    }`}
                  >
                    <span>{isArabic ? opt.ar : opt.en}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Big Orange Action Button */}
          <div className="pt-1">
            <button
              type="button"
              onClick={handleToggleTimer}
              className={`w-full py-3.5 px-6 rounded-lg font-bold text-base flex items-center justify-center gap-2 text-white shadow-sm transition-all cursor-pointer active:scale-[0.99] ${
                isRunning
                  ? 'bg-neutral-800 hover:bg-neutral-900'
                  : 'bg-[#e85933] hover:bg-[#d54924]'
              }`}
            >
              {isRunning ? (
                <>
                  <RotateCcw className="w-4 h-4 text-red-400" />
                  <span>{isArabic ? 'إلغاء المؤقت' : 'Abort Timer'}</span>
                </>
              ) : (
                <>
                  <ArrowDown className="w-4 h-4" />
                  <span>{isArabic ? 'بدء المؤقت' : 'Start Timer'}</span>
                </>
              )}
            </button>
          </div>

          {/* Bottom Status Card */}
          <div className="bg-white rounded-xl border border-neutral-200/90 p-4 shadow-xs space-y-2.5">
            <div className="text-xs text-neutral-600 font-medium">
              {isRunning ? (
                <div className="flex items-center justify-between">
                  <span>
                    {isArabic 
                      ? `قيد التشغيل — متبقي ${formatTime(remainingSeconds)}` 
                      : `Running — ${formatTime(remainingSeconds)} remaining`}
                  </span>
                  <span className="font-mono text-xs text-neutral-700 font-bold">
                    {Math.round(progressPercent)}%
                  </span>
                </div>
              ) : (
                <span>
                  {isArabic 
                    ? `جاهز — حدد المدة (${timeUnit === 'hours' ? 'بالساعات' : 'بالدقائق'}) والنوع واضغط على بدء المؤقت` 
                    : `Ready — set duration (${timeUnit}) & action, then press Start Timer`}
                </span>
              )}
            </div>

            {/* Slim progress bar with orange thumb */}
            <div className="relative w-full h-1.5 bg-[#f0ede6] rounded-full overflow-hidden" dir="ltr">
              <div 
                className="h-full bg-[#e85933] rounded-full transition-all duration-300"
                style={{ width: `${isRunning ? Math.max(2, progressPercent) : 2}%` }}
              />
            </div>
          </div>


      </div>

      {/* Force Lock Screen Simulation Overlay */}
      {isLockScreenActive && (
        <LockScreen
          onUnlock={() => setIsLockScreenActive(false)}
          expectedPin={pinCode || '1234'}
          actionType={actionType}
          reason={isArabic ? 'انتهاء وقت المؤقت المحدد' : 'Scheduled Timer Expired'}
          isArabic={isArabic}
        />
      )}

      {/* Export EXE Modal */}
      <ExportExeModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        config={currentConfig}
        isArabic={isArabic}
      />

    </div>
  );
}
