import React, { useState } from 'react';
import { X, Download, Terminal, Code, Cpu, Check, Copy, ExternalLink, ShieldCheck } from 'lucide-react';
import { ShutdownConfig, downloadFile, generateBatchScript, generateAbortScript, generatePythonScript, generateBuildExeBatch } from '../utils/scripts';
import { sounds } from '../utils/audio';

interface ExportExeModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: ShutdownConfig;
  isArabic: boolean;
}

export const ExportExeModal: React.FC<ExportExeModalProps> = ({
  isOpen,
  onClose,
  config,
  isArabic,
}) => {
  const [copiedTab, setCopiedTab] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'bat' | 'py' | 'cmd'>('bat');

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    sounds.playClick();
    navigator.clipboard.writeText(text);
    setCopiedTab(id);
    setTimeout(() => setCopiedTab(null), 2500);
  };

  const getCmdCommand = () => {
    const forceFlag = config.forceKill ? '/f' : '';
    if (config.action === 'shutdown') {
      return `shutdown /s ${forceFlag} /t ${config.totalSeconds}`;
    }
    if (config.action === 'restart') {
      return `shutdown /r ${forceFlag} /t ${config.totalSeconds}`;
    }
    if (config.action === 'lock') {
      return `rundll32.exe user32.dll,LockWorkStation`;
    }
    return `rundll32.exe powrprof.dll,SetSuspendState 0,1,0`;
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
      dir={isArabic ? 'rtl' : 'ltr'}
    >
      <div className="bg-white rounded-2xl shadow-2xl border border-neutral-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header matching modern desktop window style */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#f4f2ee] border-b border-neutral-200">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#e85933] text-white flex items-center justify-center font-black text-sm shadow-sm">
              EXE
            </div>
            <div>
              <h2 className="font-bold text-neutral-900 text-base">
                {isArabic ? 'تصدير وتحميل البرنامج كـ EXE لويندوز' : 'Export & Run as Windows Executable (EXE)'}
              </h2>
              <p className="text-xs text-neutral-500">
                {isArabic ? 'خيارات التشغيل المباشر أو التحويل إلى ملف تنفيذي مستقل' : 'Direct execution files & Standalone executable compiler'}
              </p>
            </div>
          </div>
          <button 
            onClick={() => { sounds.playClick(); onClose(); }}
            className="p-1.5 rounded-lg hover:bg-neutral-200 text-neutral-500 hover:text-neutral-900 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex border-b border-neutral-200 bg-neutral-50/70 px-6 pt-2 gap-2 text-sm font-semibold">
          <button
            onClick={() => { sounds.playClick(); setActiveTab('bat'); }}
            className={`flex items-center gap-2 py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'bat' 
                ? 'border-[#e85933] text-[#e85933]' 
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>{isArabic ? 'ملف Bat تشغيل فوري (موصى به)' : 'One-Click .BAT Script (Recommended)'}</span>
          </button>

          <button
            onClick={() => { sounds.playClick(); setActiveTab('py'); }}
            className={`flex items-center gap-2 py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'py' 
                ? 'border-[#e85933] text-[#e85933]' 
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>{isArabic ? 'صنع ملف EXE حقيقي (Python)' : 'Create True .EXE (Python / PyInstaller)'}</span>
          </button>

          <button
            onClick={() => { sounds.playClick(); setActiveTab('cmd'); }}
            className={`flex items-center gap-2 py-3 px-4 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'cmd' 
                ? 'border-[#e85933] text-[#e85933]' 
                : 'border-transparent text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>{isArabic ? 'أمر CMD مباشر' : 'Quick CMD Command'}</span>
          </button>
        </div>

        {/* Body content based on activeTab */}
        <div className="p-6">
          {activeTab === 'bat' && (
            <div className="space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold mb-1">
                    {isArabic ? 'طريقة فورية تعمل على جميع أجهزة ويندوز بدون برامج إضافية:' : 'Instant zero-dependency method for all Windows versions:'}
                  </div>
                  <div>
                    {isArabic 
                      ? 'ملف .BAT ينفذ أمر الإغلاق الإجباري مع مؤقت زمني بدقة متناهية وإغلاق كافة التطبيقات العالقة.'
                      : 'A .BAT script directly commands Windows to initiate forced countdown and terminate all hanging processes.'}
                  </div>
                </div>
              </div>

              {/* Action Buttons to download */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => {
                    sounds.playClick();
                    const batContent = generateBatchScript(config);
                    downloadFile(`Force_${config.action}_${config.totalSeconds}s.bat`, batContent);
                  }}
                  className="p-4 rounded-xl bg-[#e85933] hover:bg-[#d04a25] text-white flex flex-col items-center justify-center gap-1.5 shadow-md shadow-orange-900/10 cursor-pointer transition-all hover:scale-[1.01]"
                >
                  <Download className="w-5 h-5" />
                  <span className="font-bold text-sm">
                    {isArabic ? 'تحميل ملف التشغيل (.bat)' : 'Download Action Script (.bat)'}
                  </span>
                  <span className="text-[11px] text-white/80 font-mono-numbers">
                    {config.action.toUpperCase()} · {config.totalSeconds}s · FORCE
                  </span>
                </button>

                <button
                  onClick={() => {
                    sounds.playClick();
                    const abortContent = generateAbortScript();
                    downloadFile('Cancel_Shutdown.bat', abortContent);
                  }}
                  className="p-4 rounded-xl bg-neutral-100 hover:bg-neutral-200 border border-neutral-300 text-neutral-800 flex flex-col items-center justify-center gap-1.5 cursor-pointer transition-all hover:scale-[1.01]"
                >
                  <Download className="w-5 h-5 text-neutral-600" />
                  <span className="font-bold text-sm">
                    {isArabic ? 'تحميل ملف إلغاء الإغلاق (Abort)' : 'Download Abort Script (Cancel)'}
                  </span>
                  <span className="text-[11px] text-neutral-500 font-mono-numbers">
                    shutdown /a
                  </span>
                </button>
              </div>

              {/* Code preview snippet */}
              <div className="relative mt-3">
                <div className="text-xs font-semibold text-neutral-500 mb-1">
                  {isArabic ? 'معاينة كود الملف:' : 'Script Code Preview:'}
                </div>
                <pre className="bg-neutral-900 text-neutral-200 p-3.5 rounded-xl text-xs font-mono overflow-x-auto border border-neutral-800" dir="ltr">
                  {generateBatchScript(config).slice(0, 360)}...
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'py' && (
            <div className="space-y-4">
              <p className="text-xs text-neutral-600">
                {isArabic
                  ? 'يمكنك الحصول على ملف EXE حقيقي بنفس واجهة البرنامج من خلال كود بايثون الجاهز وأداة البناء بنقرة واحدة:'
                  : 'Get a genuine standalone .exe with this exact graphic user interface using Python + PyInstaller in 1 minute:'}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    sounds.playClick();
                    const pyContent = generatePythonScript(config.totalSeconds);
                    downloadFile('PowerTimer.py', pyContent, 'text/x-python');
                  }}
                  className="p-3.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Download className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-xs">{isArabic ? '1. تحميل ملف PowerTimer.py' : '1. Download PowerTimer.py'}</span>
                </button>

                <button
                  onClick={() => {
                    sounds.playClick();
                    const buildContent = generateBuildExeBatch();
                    downloadFile('Build_EXE.bat', buildContent);
                  }}
                  className="p-3.5 rounded-xl bg-[#e85933] hover:bg-[#d04a25] text-white flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span className="font-bold text-xs">{isArabic ? '2. تحميل أداة التجميع Build_EXE.bat' : '2. Download Build_EXE.bat'}</span>
                </button>
              </div>

              {/* Instructions steps */}
              <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-200 text-xs space-y-2">
                <div className="font-bold text-neutral-800">
                  {isArabic ? 'خطوات إنشاء ملف الـ EXE:' : 'How to generate the .EXE file:'}
                </div>
                <ol className="list-decimal list-inside space-y-1 text-neutral-600">
                  <li>{isArabic ? 'ضع الملفين PowerTimer.py و Build_EXE.bat في نفس المجلد' : 'Place PowerTimer.py and Build_EXE.bat in the same folder'}</li>
                  <li>{isArabic ? 'انقر مرتين على Build_EXE.bat (سيقوم بتثبيت pyinstaller وبناء ملف الـ EXE تلقائياً)' : 'Double click Build_EXE.bat (it auto-compiles the EXE with no console window)'}</li>
                  <li>{isArabic ? 'ستجد البرنامج التنفيذي في مجلد dist\\PowerTimer.exe جاهزاً للتشغيل في أي وقت!' : 'Your ready-to-use PowerTimer.exe will appear in dist\\PowerTimer.exe!'}</li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'cmd' && (
            <div className="space-y-4">
              <p className="text-xs text-neutral-600">
                {isArabic
                  ? 'إذا كنت تريد تشغيل الأمر فوراً من خلال نافذة التشغيل (Win + R) أو موجه الأوامر CMD:'
                  : 'Run immediately from Windows Run dialog (Win + R) or Command Prompt:'}
              </p>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-neutral-500">
                  {isArabic ? 'أمر الإغلاق الإجباري المخصص لإعداداتك الحالية:' : 'Configured Command:'}
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={getCmdCommand()}
                    className="flex-1 bg-neutral-900 text-emerald-400 font-mono text-xs py-2.5 px-3.5 rounded-xl border border-neutral-800 select-all"
                    dir="ltr"
                  />
                  <button
                    onClick={() => handleCopy(getCmdCommand(), 'cmd_main')}
                    className="px-4 py-2.5 rounded-xl bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedTab === 'cmd_main' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedTab === 'cmd_main' ? (isArabic ? 'تم النسخ' : 'Copied') : (isArabic ? 'نسخ' : 'Copy')}</span>
                  </button>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <div className="text-xs font-semibold text-neutral-500">
                  {isArabic ? 'أمر إلغاء الإغلاق الفوري في حال التراجع:' : 'Cancel Command (Win + R):'}
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value="shutdown /a"
                    className="flex-1 bg-neutral-900 text-orange-400 font-mono text-xs py-2.5 px-3.5 rounded-xl border border-neutral-800 select-all"
                    dir="ltr"
                  />
                  <button
                    onClick={() => handleCopy('shutdown /a', 'cmd_abort')}
                    className="px-4 py-2.5 rounded-xl bg-neutral-200 hover:bg-neutral-300 text-neutral-800 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copiedTab === 'cmd_abort' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedTab === 'cmd_abort' ? (isArabic ? 'تم النسخ' : 'Copied') : (isArabic ? 'نسخ' : 'Copy')}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-neutral-100 border-t border-neutral-200 flex items-center justify-between">
          <div className="text-[11px] text-neutral-500">
            {isArabic ? 'متوافق مع Windows 11 / 10 / 8 / 7 (32-bit & 64-bit)' : 'Compatible with Windows 11 / 10 / 8 / 7 (32/64-bit)'}
          </div>
          <button
            onClick={() => { sounds.playClick(); onClose(); }}
            className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-900 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            {isArabic ? 'إغلاق' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
};
