import React, { useState } from 'react';
import { MEDIA_LAB_LOGO_BASE64 } from '../assets/logoBase64';

interface MediaLabLogoProps {
  className?: string;
}

export const MediaLabLogo: React.FC<MediaLabLogoProps> = ({ className = '' }) => {
  const [imgSrc, setImgSrc] = useState('/mediaLab_publishing_transparent.png');

  return (
    <div className={`inline-flex items-center select-none ${className}`}>
      <img
        src={imgSrc}
        alt="mediaLab publishing"
        className="h-12 sm:h-14 w-auto object-contain pointer-events-none"
        draggable={false}
        onError={() => {
          if (imgSrc !== MEDIA_LAB_LOGO_BASE64) {
            setImgSrc(MEDIA_LAB_LOGO_BASE64);
          }
        }}
      />
    </div>
  );
};
